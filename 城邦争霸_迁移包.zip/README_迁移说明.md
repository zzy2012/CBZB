# 城邦争霸复刻 · 迁移包说明

这个文件夹包含本次会话产出的全部内容，可以直接拷到另一台电脑继续。

```
迁移包/
├─ 代码变更/                # 相对 E:\GIT\TEngine 的完整路径镜像（142 个文件）
├─ DELETED_FILES.txt        # 需要在目标机上删除的文件（1 个）
├─ session_transcript.md    # 本次会话的可读记录（含全部决策与工具调用）
├─ 会话恢复/                # DSH 原生会话文件（想在另一台机继续这个对话才需要）
└─ README_迁移说明.md
```

---

## 一、迁移代码（必需）

目标机前提：已经有一份 **TEngine 仓库**，并且 Unity 版本为 **2022.3.20f1**。

1. 把 `代码变更/` 里的内容**按原路径覆盖**到仓库根目录（`E:\GIT\TEngine`）。
2. 按 `DELETED_FILES.txt` 删除对应文件（只有一个）。
3. **不要拷贝** `UnityProject/Library`、`Temp`、`obj`、`Builds` —— 让 Unity 重新生成。
4. 打开 Unity 工程，等待导入完成，进 `Assets/Scenes/main.unity`，按 Play。

### 已经包含、不需要重新生成的东西

| 内容 | 位置 |
|---|---|
| 6 张 Luban 表的 Excel | `Configs/GameConfig/Datas/*.xlsx` |
| Luban 生成的代码 | `UnityProject/Assets/GameScripts/HotFix/GameProto/GameConfig/takeover/` |
| Luban 生成的二进制 | `UnityProject/Assets/AssetRaw/Configs/bytes/takeover_*.bytes` |
| 玩法代码 | `UnityProject/Assets/GameScripts/HotFix/GameLogic/Takeover/` |
| 数值/地图文档 | `Docs/城邦争霸数值/`、`Docs/城邦争霸复刻.md` |

> 只有**修改了 Excel 表**时，才需要重跑 `Configs/GameConfig/gen_code_bin_to_project.bat`。

### 首次打开可能遇到的坑

- **`CS0246: takeover 找不到`**：这是 Luban 生成文件尚未被 AssetDatabase 收录时的瞬时错误。切到 Unity 窗口按一次 `Ctrl+R` 强制刷新即可。
- 如果想在命令行触发：给 Unity 窗口焦点后发 `Ctrl+R`，等 `Library/ScriptAssemblies/GameLogic.dll` 时间戳更新。

---

## 二、外部数据（可选，68MB）

这些不在 git 仓库里，放在 `E:\GameData\`：

| 目录 | 内容 | 是否需要 |
|---|---|---|
| `城邦争霸_Takeover\` | 4399 游戏本体 SWF（20MB）、FFDec、1437 个反编译 AS 文件、提取脚本 | **只在想继续做数值考据时需要** |
| `takeover_simtest\` | 无头模拟测试台（dotnet 8），跑 24 关扫描与单元测试 | 想改平衡时需要 |

不需要的话完全不用拷——游戏运行不依赖它们。

---

## 三、恢复会话记录（可选）

- **只想看记录**：直接看 `session_transcript.md`。
- **想在另一台机继续这个对话**：
  1. 目标机工作目录也必须是 `E:\GIT\TEngine`；
  2. 把 `会话恢复/session.v4.jsonl.zstd` 放到
     `C:\Users\<用户名>\.dsh\sessions\--E-GIT-TEngine--\session-34312314-5b75-4b53-a659-a89316b4c6c2\`
  3. 重启 DSH，历史里会出现这次会话。

> 会话文件是 zstd 压缩的 jsonl，体积 2.6MB，路径编码了工作目录；工作目录不同则不会出现在同一 workspace 下。

---

## 四、当前完成度（给接手的人）

| 模块 | 状态 |
|---|---|
| 数值（45 兵种 / 7 建筑 / 16 法术 / 81 条教令） | 已完成 |
| 地图（24 关 + 教学，748 节点 / 515 道路） | 已完成 |
| 战斗模拟（经济、造兵、建造、寻路、远程、驻军、占领、胜负） | 已完成 |
| AI（买兵、铺农场、升级、进攻、残血撤退、增援） | 已完成 |
| 战役（星级、经验、教令点、解锁） | 已完成 |
| 表现层（运行时地图、HUD、选中/下令、相机平移缩放） | 已完成（IMGUI 调试风） |
| 法术系统 | 未做（配置已就绪） |
| 教令解锁 UI | 未做（数据与 API 已就绪） |
| 兵种相克与特技（冲锋/盾墙/毒等） | 未做（字段已解析） |

详细说明见 `Docs/城邦争霸复刻.md`。
